---
name: OpenWPS Clarity
colors:
  surface: '#fcf8ff'
  surface-dim: '#dbd8e6'
  surface-bright: '#fcf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2ff'
  surface-container: '#efecfa'
  surface-container-high: '#eae6f4'
  surface-container-highest: '#e4e1ee'
  on-surface: '#1b1b24'
  on-surface-variant: '#474651'
  inverse-surface: '#302f3a'
  inverse-on-surface: '#f2effd'
  outline: '#777682'
  outline-variant: '#c8c5d3'
  surface-tint: '#5655a8'
  primary: '#060046'
  on-primary: '#ffffff'
  primary-container: '#1a146b'
  on-primary-container: '#8482d9'
  inverse-primary: '#c3c0ff'
  secondary: '#085ac0'
  on-secondary: '#ffffff'
  secondary-container: '#5b94fd'
  on-secondary-container: '#002c66'
  tertiary: '#00130a'
  on-tertiary: '#ffffff'
  tertiary-container: '#002b1b'
  on-tertiary-container: '#5e977b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#100563'
  on-primary-fixed-variant: '#3e3c8f'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#b4f0cf'
  tertiary-fixed-dim: '#98d3b4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#145038'
  background: '#fcf8ff'
  on-background: '#1b1b24'
  surface-variant: '#e4e1ee'
  writer-blue: '#2563eb'
  sheet-emerald: '#059669'
  slide-orange: '#ea580c'
  pdf-red: '#dc2626'
  surface-lowest: '#ffffff'
  surface-background: '#f8f9ff'
typography:
  display-title:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  display-title-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  section-title:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-main:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  button-label:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  metadata:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 16px
  gutter: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  touch-target: 48px
  nav-bar-height: 56px
  header-height: 64px
---

## Brand & Style
The brand is defined by **Corporate Modernism** with a focus on productivity, clarity, and reliability. It targets professional users who require a high-performance office suite that feels both powerful and approachable. 

The aesthetic leverages a "Soft-Modern" approach: a blend of high-utility systematic layouts and friendly, rounded container elements. The emotional response is one of organized efficiency—using a calming palette of deep indigos and soft blues to reduce cognitive load during complex tasks.

## Colors
The palette is rooted in a professional **Indigo Primary** (#1a146b), signaling stability and depth. The secondary blue provides a more active, digital-first feel for interactive elements like the navigation bar.

A "Tonal Surface" strategy is used: 
- **Backgrounds** use a very cool-white/blue tint (#f8f9ff) to provide a soft canvas.
- **Interactive Containers** use pure white (#ffffff) to "pop" against the background without requiring heavy shadows.
- **Semantic Accents** are used for file types (Writer, Spreadsheet, etc.), providing immediate visual recognition through distinct hues (Blue, Emerald, Orange, Red) while maintaining consistent saturation levels.

## Typography
The system uses **Inter** exclusively to maintain a utilitarian and systematic feel. 

- **Hierarchy:** Strong contrast is achieved through weight rather than just size. Headlines use `Bold` or `Semi-Bold` with negative letter-spacing to appear tighter and more professional.
- **Micro-copy:** Metadata and secondary information use a medium weight (500) at 13px to maintain legibility while clearly receding behind primary labels.
- **Actionable text:** Navigation and button labels use 15px with `Semi-Bold` weight to clearly distinguish them from standard body text.

## Layout & Spacing
The layout follows a **Fluid Content Model** with strict horizontal margins and a modular vertical rhythm.

- **Margins:** A consistent 16px safe area is maintained on mobile.
- **Grid:** Bento-style grids for quick actions use a 12px gutter to balance density with tap-target safety.
- **Vertical Rhythm:** A "Stack" system (8/16/24) governs spacing between related elements versus distinct sections.
- **Tap Targets:** All interactive icons and navigation items are mapped to a 48px minimum hit area to ensure accessibility on touch devices.

## Elevation & Depth
Depth is communicated through **Subtle Ambient Shadows** and **Tonal Layering**.

- **Level 0 (Background):** The base surface (#f8f9ff).
- **Level 1 (Cards/Items):** White surfaces (#ffffff) with a very soft, diffused shadow `0 2px 8px rgba(0,0,0,0.04)`. This creates a "floating" effect that distinguishes interactive content from the background without harsh borders.
- **Level 2 (Floating Action Button):** High-contrast primary color with a deeper indigo-tinted shadow `0 4px 16px rgba(26,20,107,0.24)` to indicate it is the highest element in the Z-space.
- **Bottom Navigation:** Uses a subtle top shadow and standard background color to feel anchored.

## Shapes
The shape language is **Generously Rounded**, moving away from standard enterprise rigidity to feel more modern and ergonomic.

- **Primary Containers (Cards):** Use a 16px radius.
- **Small Components (Icons/Chips):** Use a 12px radius.
- **Avatar/FAB:** Use fully circular (9999px) shapes to draw the eye and denote "person" or "primary action".
- **Interactive Feedback:** Elements should subtly scale (e.g., 98%) on press to reinforce the tactile nature of the shapes.

## Components
- **Buttons:** Primary buttons are pill-shaped or high-radius. Quick Create buttons are large cards (square-ish but 16px rounded) with top-aligned icons.
- **Cards (Bento Style):** Fixed-aspect or flexible containers that group an icon and a label. Use a light background tint for the icon container to match the file type's semantic color.
- **List Items:** Horizontal layout with an 8px or 12px rounded icon container, a multi-line text block (Title + Metadata), and a trailing "More" icon.
- **Navigation:** A fixed bottom bar with clear active/inactive states. Active states use the secondary blue; inactive states use a medium-contrast neutral gray.
- **FAB:** A signature 56px circle in the primary brand color, always positioned in the bottom-right with high elevation.
- **Icons:** Use "Material Symbols Outlined" with a custom fill weight for active states to add visual "heft."